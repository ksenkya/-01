from PySide6.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QFrame, QSpacerItem, QSizePolicy, QStackedWidget, QLineEdit, QComboBox, QFormLayout, QSpinBox, 
    QScrollArea, QTableWidgetItem, QTableWidget, QMessageBox, QDialog
)
from PySide6.QtGui import QFont, QIcon
from PySide6.QtCore import Qt

from datebase import Partner, Type_partner, Legal_address, Connect

class PartnerForm(QWidget):
    def __init__(self, partner_id=None):
        super().__init__()
        self.setWindowTitle("Добавление/Редактирование партнера")
        self.setGeometry(200, 200, 400, 500)
        
        self.session = Connect.create_connection()
        self.partner_id = partner_id  # Сохраняем id партнера для редактирования, если оно есть
        self.setup_ui()

    def setup_ui(self):
        layout = QFormLayout(self)
        
        # Поля для ввода
        self.name_input = QLineEdit(self)
        self.inn_input = QLineEdit(self)  # Поле для ИНН
        self.director_input = QLineEdit(self)
        self.phone_input = QLineEdit(self)
        self.email_input = QLineEdit(self)
        self.rating_input = QSpinBox(self)
        self.rating_input.setRange(0, 100)  # Диапазон от 0 до 100 для рейтинга

        # Выпадающий список для типа партнера
        self.type_combo = QComboBox(self)
        self.load_partner_types()

        # Выпадающий список для юридического адреса
        self.address_combo = QComboBox(self)
        self.load_legal_addresses()

        # Кнопки
        self.submit_button = QPushButton("Сохранить", self)
        self.submit_button.clicked.connect(self.save_partner)

        # Добавление полей в форму
        layout.addRow("Наименование:", self.name_input)
        layout.addRow("ИНН:", self.inn_input)
        layout.addRow("Директор:", self.director_input)
        layout.addRow("Телефон:", self.phone_input)
        layout.addRow("Email:", self.email_input)
        layout.addRow("Рейтинг:", self.rating_input)
        layout.addRow("Тип партнера:", self.type_combo)
        layout.addRow("Юридический адрес:", self.address_combo)
        layout.addRow(self.submit_button)

        # Если редактирование, то заполняем поля данными партнера
        if self.partner_id:
            self.load_partner_data()

    def load_partner_types(self):
        """Загружаем типы партнеров из базы данных в выпадающий список"""
        partner_types = self.session.query(Type_partner).all()
        for partner_type in partner_types:
            self.type_combo.addItem(partner_type.наименование, partner_type.id)

    def load_legal_addresses(self):
        """Загружаем юридические адреса из базы данных в выпадающий список"""
        legal_addresses = self.session.query(Legal_address).all()
        for address in legal_addresses:
            # Формируем строку с полным адресом
            full_address = f"{address.регион}, {address.город}, {address.улица}, {address.дом}"
            self.address_combo.addItem(full_address, address.id)
    
    def load_partner_data(self):
        """Загружаем данные партнера для редактирования"""
        partner = self.session.query(Partner).get(self.partner_id)
        self.name_input.setText(partner.наименование)
        self.inn_input.setText(partner.инн)
        self.director_input.setText(partner.фио_директора)
        self.phone_input.setText(partner.телефон)
        self.email_input.setText(partner.email)
        self.rating_input.setValue(int(partner.рейтинг))
        
        # Устанавливаем тип партнера и юридический адрес
        self.type_combo.setCurrentText(partner.тип_партнера.наименование)
        self.address_combo.setCurrentText(f"{partner.юридический_адрес.регион}, {partner.юридический_адрес.город}, {partner.юридический_адрес.улица}, {partner.юридический_адрес.дом}")

    def save_partner(self):
        """Сохраняем данные партнера в базе данных"""
        partner_type_id = self.type_combo.currentData()  # Получаем id выбранного типа
        address_id = self.address_combo.currentData()  # Получаем id выбранного адреса

        if self.partner_id:
            # Редактируем существующего партнера
            partner = self.session.query(Partner).get(self.partner_id)
        else:
            # Создаем нового партнера
            partner = Partner()

        partner.наименование = self.name_input.text()
        partner.инн = self.inn_input.text()
        partner.фио_директора = self.director_input.text()
        partner.телефон = self.phone_input.text()
        partner.email = self.email_input.text()
        partner.рейтинг = str(self.rating_input.value())
        partner.id_тип = partner_type_id
        partner.id_юр_адрес = address_id

        if not self.partner_id:  # Если это новый партнер, добавляем в базу
            self.session.add(partner)

        self.session.commit()  # Сохраняем изменения
        
        self.close()  # Закрываем форму после сохранения