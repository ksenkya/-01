from PySide6.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QFrame, QSpacerItem, QSizePolicy, QStackedWidget, QLineEdit, QComboBox, QFormLayout, QSpinBox, 
    QScrollArea, QTableWidgetItem, QTableWidget, QMessageBox, QDialog
)
from PySide6.QtGui import QFont, QIcon
from PySide6.QtCore import Qt, Signal

from datebase import Partner, Type_partner, Legal_address, Connect, history_implementation, Products

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics

class PartnerForm(QDialog):
    partner_updated = Signal()
    def __init__(self, partner_id=None):
        super().__init__()
        self.partner_id = partner_id
        self.setWindowTitle("Добавить партнёра" if not partner_id else "Редактировать партнёра")
        self.setWindowIcon(QIcon("icon.ico"))
        self.setGeometry(300, 300, 400, 300)
        self.session = Connect.create_connection()
        self.setup_ui()
        
        # Если партнёр уже выбран для редактирования, загружаем данные
        if self.partner_id:
            self.load_partner_data()

    def setup_ui(self):
        layout = QVBoxLayout(self)

        # Поля формы
        self.name_input = QLineEdit(self)
        self.partner_type_input = QComboBox(self)
        self.rating_input = QSpinBox(self)
        self.address_input = QLineEdit(self)
        self.director_input = QLineEdit(self)
        self.phone_input = QLineEdit(self)
        self.email_input = QLineEdit(self)

        # Настройка выпадающего списка для типа партнёра
        self.partner_type_input.addItems(["Тип 1", "Тип 2", "Тип 3"])  # Замените на реальные типы

        # Ограничение рейтинга
        self.rating_input.setRange(0, 100)
        
        # Размещение виджетов на форме
        layout.addWidget(QLabel("Наименование"))
        layout.addWidget(self.name_input)

        layout.addWidget(QLabel("Тип партнёра"))
        layout.addWidget(self.partner_type_input)

        layout.addWidget(QLabel("Рейтинг"))
        layout.addWidget(self.rating_input)

        layout.addWidget(QLabel("Адрес"))
        layout.addWidget(self.address_input)

        layout.addWidget(QLabel("ФИО Директора"))
        layout.addWidget(self.director_input)

        layout.addWidget(QLabel("Телефон"))
        layout.addWidget(self.phone_input)

        layout.addWidget(QLabel("Email"))
        layout.addWidget(self.email_input)

        # Кнопка сохранения
        self.save_button = QPushButton("Сохранить", self)
        self.save_button.clicked.connect(self.save_partner)
        layout.addWidget(self.save_button)

    def load_partner_data(self):
        """Загружает данные партнёра для редактирования."""
        partner = self.session.query(Partner).filter_by(id=self.partner_id).first()
        if partner:
            self.name_input.setText(partner.наименование)
            self.partner_type_input.setCurrentText(partner.тип_партнера.наименование)
            self.rating_input.setValue(partner.рейтинг)
            self.address_input.setText(partner.юридический_адрес.город)
            self.director_input.setText(partner.фио_директора)
            self.phone_input.setText(partner.телефон)
            self.email_input.setText(partner.email)

    def save_partner(self):
        """Сохраняет нового или отредактированного партнёра в базу данных."""
        name = self.name_input.text()
        partner_type = self.partner_type_input.currentText()
        rating = self.rating_input.value()
        address = self.address_input.text()
        director = self.director_input.text()
        phone = self.phone_input.text()
        email = self.email_input.text()

        # Валидация данных (например, обязательные поля)
        if not name or not phone or not email:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, заполните все обязательные поля.")
            return

        # Если редактируем партнёра
        if self.partner_id:
            partner = self.session.query(Partner).filter_by(id=self.partner_id).first()
            if partner:
                partner.наименование = name
                partner.тип_партнера.наименование = partner_type
                partner.рейтинг = rating
                partner.юридический_адрес.город = address
                partner.фио_директора = director
                partner.телефон = phone
                partner.email = email
        else:
            # Если добавляем нового партнёра
            new_partner = Partner(
                наименование=name,
                тип_партнера=partner_type,
                рейтинг=rating,
                адрес=address,
                фио_директора=director,
                телефон=phone,
                email=email
            )
            self.session.add(new_partner)

        self.session.commit()
        QMessageBox.information(self, "Успех", "Данные партнёра сохранены.")
        self.accept()  # Закрываем форму

    def closeEvent(self, event):
        # Обновляем список партнёров в главной форме после закрытия окна
        self.parent().reload_partners()

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Мастер пол")
        self.setWindowIcon(QIcon("icon.ico"))
        self.setGeometry(100, 100, 800, 600)
        self.session = Connect.create_connection()
        self.selected_partner_id = None  # Добавим переменную для хранения ID выбранного партнёра
        self.setup_ui()

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        top_bar = QFrame(self)
        top_bar.setStyleSheet("background-color: #F2F2F2; padding: 10px;")
        top_bar_layout = QHBoxLayout()

        main_menu_button = QPushButton("Главное меню", top_bar)
        our_partners_button = QPushButton("Наши партнеры", top_bar)
        history_button = QPushButton("История", top_bar)

        for button in [main_menu_button, our_partners_button, history_button]:
            button.setStyleSheet("background-color: transparent; border: none; color: #333; font-weight: bold; padding: 5px 10px; margin-right: 20px;")
            top_bar_layout.addWidget(button)

        top_bar_layout.addSpacerItem(QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
        top_bar.setLayout(top_bar_layout)

        main_layout.addWidget(top_bar)

        self.stacked_widget = QStackedWidget(self)
        main_layout.addWidget(self.stacked_widget)

        self.main_menu_page = QWidget(self)
        self.our_partners_page = QWidget(self)
        self.history_page = QWidget(self)

        self.stacked_widget.addWidget(self.main_menu_page)
        self.stacked_widget.addWidget(self.our_partners_page)
        self.stacked_widget.addWidget(self.history_page)

        self.stacked_widget.setCurrentWidget(self.main_menu_page)

        self.show_main_menu()
        self.setup_our_partners()
        self.setup_history_page()

        main_menu_button.clicked.connect(self.show_main_menu)
        our_partners_button.clicked.connect(self.show_our_partners)
        history_button.clicked.connect(self.show_history)

    def setup_our_partners(self):
        # Заполнение страницы "Наши партнеры"
        layout = QVBoxLayout(self.our_partners_page)  # Создаём макет для страницы "Наши партнёры"
        label = QLabel("Наши партнёры", self.our_partners_page)
        label.setFont(QFont("Arial", 18))
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        # Создаём область для прокрутки
        scroll_area = QScrollArea(self.our_partners_page)
        scroll_area.setWidgetResizable(True)  # Сделаем так, чтобы содержимое изменяло размер в зависимости от области
        scroll_area_content = QWidget()  # Это будет контейнер для всех карточек
        scroll_area.setWidget(scroll_area_content)

        # Создаём вертикальный макет для карточек партнёров
        partners_layout = QVBoxLayout(scroll_area_content)

        # Получаем данные партнёров из базы
        partners = self.session.query(Partner).all()

        # Создание карточек для каждого партнёра
        for partner in partners:
            partner_card = QFrame(scroll_area_content)
            partner_card.setStyleSheet("""
                QFrame {
                    background-color: #FFF;
                    border: 1px solid #DDD;
                    padding: 10px;
                    margin-bottom: 10px;
                    border-radius: 5px;
                }
                QFrame:hover {
                    background-color: #f5f5f5;
                }
            """)
            partner_card_layout = QVBoxLayout(partner_card)

            # Формирование текста с данными о партнёре
            partner_info = QLabel(
                f"{partner.тип_партнера.наименование} | {partner.наименование}\n"
                f"Директор: {partner.фио_директора}\n"
                f"Телефон: {partner.телефон}\n"
                f"Рейтинг: {partner.рейтинг}",
                partner_card
            )
            partner_info.setFont(QFont("Arial", 12))
            partner_info.setAlignment(Qt.AlignLeft)

            # Добавление элементов в карточку
            partner_card_layout.addWidget(partner_info)
            
            # Шаг 1: Получаем скидку для партнера
            discount = self.calculate_discount_for_partner(partner.id, self.session)
    
            # Шаг 2: Добавляем метку с отображением скидки в правую часть карточки
            discount_label = QLabel(f"Скидка: {discount}%", partner_card)
            discount_label.setFont(QFont("Arial", 12))
            discount_label.setAlignment(Qt.AlignRight)  # Выравнивание вправо
            discount_label.setStyleSheet("""
                QLabel {
                    font-weight: bold;
                    color: #4CAF50;
                }
            """)
    
            partner_card_layout.addWidget(discount_label)

            # Подключаем обработчик клика на карточку
            partner_card.mousePressEvent = lambda event, partner_id=partner.id: self.select_partner(partner_id)

            # Добавляем карточку в макет
            partners_layout.addWidget(partner_card)

        # Добавляем прокручиваемую область на страницу
        layout.addWidget(scroll_area)

        # Добавление пустого пространства для сдвига кнопки вниз
        layout.addSpacerItem(QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))

        # Кнопка для добавления нового партнера
        add_partner_button = QPushButton("Добавить нового партнера", self.our_partners_page)
        add_partner_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-size: 14px;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        add_partner_button.clicked.connect(self.add_partner)

        layout.addWidget(add_partner_button)  # Добавляем кнопку внизу

        # Кнопка редактирования для выбранного партнёра
        self.edit_partner_button = QPushButton("Редактировать выбранного партнера", self.our_partners_page)
        self.edit_partner_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                font-size: 14px;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        self.edit_partner_button.setEnabled(False)  # Изначально кнопка недоступна
        self.edit_partner_button.clicked.connect(self.edit_selected_partner)
        layout.addWidget(self.edit_partner_button)
        
        # Кнопка для создания отчета
        generate_report_button = QPushButton("Создать отчет", self.our_partners_page)
        generate_report_button.setStyleSheet("""
            QPushButton {
                background-color: #FF9800;
                color: white;
                font-size: 14px;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #FB8C00;
            }
        """)
        generate_report_button.clicked.connect(self.generate_report)  # Подключаем метод для создания отчета
        layout.addWidget(generate_report_button)

    def select_partner(self, partner_id):
        """Выбираем партнера для редактирования при клике на карточку"""
        self.selected_partner_id = partner_id  # Сохраняем выбранного партнёра
        self.edit_partner_button.setEnabled(True)  # Делаем кнопку доступной для редактирования


    def edit_selected_partner(self):
        """Открывает форму редактирования для выбранного партнера"""
        if self.selected_partner_id:
            self.partner_form = PartnerForm(self.selected_partner_id)  # Передаём ID выбранного партнёра
            self.partner_form.show()
        else:
            print("Выберите партнера для редактирования.")  # Если партнёр не выбран, выводим сообщение

    def add_partner(self):
        """Открывает форму для добавления нового партнера"""
        self.partner_form = PartnerForm()  # Без id, значит добавляем нового
        self.partner_form.show()

    def reload_partners(self):
        """Обновляет список партнёров на странице 'Наши партнёры'"""
        # Очистим все текущие карточки на странице
        for i in reversed(range(self.our_partners_page.layout().count())):
            widget = self.our_partners_page.layout().itemAt(i).widget()
            if widget is not None:
                widget.deleteLater()

        # Перезаполним страницу новыми карточками партнёров
        self.setup_our_partners()
    
    def setup_history_page(self):
        """Настроить страницу Истории Реализаций."""
        layout = QVBoxLayout(self.history_page)  # Создаем макет для страницы истории
        label = QLabel("История реализации", self.history_page)
        label.setFont(QFont("Arial", 18))
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        # Создаем таблицу для отображения истории
        self.history_table = QTableWidget(self.history_page)
        self.history_table.setColumnCount(4)  # Количество столбцов
        self.history_table.setHorizontalHeaderLabels(["Партнёр", "Продукция", "Количество", "Дата продажи"])

        # Получаем данные истории реализации
        self.load_history_data()

        layout.addWidget(self.history_table)

    def load_history_data(self):
        """Загружаем данные из таблицы истории реализации."""
        # Получаем все записи из таблицы истории реализации
        history_records = self.session.query(history_implementation).all()

        # Заполняем таблицу данными
        self.history_table.setRowCount(len(history_records))  # Устанавливаем количество строк

        for row, record in enumerate(history_records):
            # Получаем данные о партнёре и продукции из внешних таблиц
            partner = self.session.query(Partner).filter(Partner.id == record.id_партнер).first()
            product = self.session.query(Products).filter(Products.id == record.id_продукция).first()

            # Заполняем строку таблицы
            self.history_table.setItem(row, 0, QTableWidgetItem(partner.наименование if partner else "Неизвестно"))
            self.history_table.setItem(row, 1, QTableWidgetItem(product.наименование if product else "Неизвестно"))
            self.history_table.setItem(row, 2, QTableWidgetItem(str(record.количество)))
            self.history_table.setItem(row, 3, QTableWidgetItem(str(record.дата_продажи)))
    
    def show_main_menu(self):
        self.stacked_widget.setCurrentWidget(self.main_menu_page)

    def show_our_partners(self):
        self.stacked_widget.setCurrentWidget(self.our_partners_page)

    def show_history(self):
        self.stacked_widget.setCurrentWidget(self.history_page)
        
    @staticmethod
    def calculate_discount_for_partner(partner_id, session):
        # Шаг 1: Получаем все записи о продажах (реализации продукции) для данного партнера
        sales_records = session.query(history_implementation).filter_by(id_партнер=partner_id).all()

        # Шаг 2: Суммируем количество реализованной продукции
        total_sales_quantity = 0
        for record in sales_records:
            total_sales_quantity += int(record.количество)  # Суммируем количество (предполагается, что оно хранится в строковом формате)

        # Шаг 3: Определяем скидку в зависимости от объема продаж
        if total_sales_quantity <= 10000:
            discount = 0
        elif 10000 < total_sales_quantity <= 50000:
            discount = 5
        elif 50000 < total_sales_quantity <= 300000:
            discount = 10
        else:
            discount = 15

        # Шаг 4: Возвращаем скидку
        return discount
    
    def generate_report(self):
        # Путь для сохранения PDF
        file_path = "file.pdf"

        # Создаем объект canvas для генерации PDF
        c = canvas.Canvas(file_path, pagesize=letter)

        # Регистрируем шрифт с поддержкой кириллицы
        pdfmetrics.registerFont(TTFont('SegoeUI', 'SegoeUIRegular.ttf'))  # Укажите путь к шрифту
        c.setFont("SegoeUI", 16)  # Устанавливаем шрифт для заголовка

        # Заголовок
        title = "PDF отчет"
        
        # Вычисляем горизонтальную позицию для центра
        title_width = c.stringWidth(title, "SegoeUI", 16)
        title_x = (letter[0] - title_width) / 2  # Центрируем заголовок по горизонтали
        c.drawString(title_x, 750, title)
        
        # Устанавливаем шрифт для основного текста
        c.setFont("SegoeUI", 12)
        text = "Продукция:"

        # Разбиваем текст на несколько строк, чтобы он не выходил за пределы страницы
        lines = text.split("\n")
        y_position = 700
        for line in lines:
            c.drawString(100, y_position, line)
            y_position -= 14  # Смещаем текст вниз на 14 единиц

        # Завершаем создание PDF
        c.save()

        # Показать сообщение об успешном создании отчета
        self.show_message("Внимание", "Отчет создан", QMessageBox.Information)
        
    def show_message(self, title, message, icon):
        # Метод для отображения сообщений
        msg = QMessageBox()
        msg.setIcon(icon)  # Устанавливаем иконку сообщения
        msg.setText(message)  # Устанавливаем текст сообщения
        msg.setWindowTitle(title)  # Устанавливаем заголовок окна сообщения
        msg.exec()  # Отображаем сообщение